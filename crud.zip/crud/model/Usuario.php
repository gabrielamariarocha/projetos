<?php


require_once('Conexao.php');

class Usuario {

    
    
    Private $nome;
    Private $sobrenome;
    Private $cpf;

   
    
    public function incluir($nome, $sobrenome, $cpf) { 

        $insert = 'insert into usuario(nome, sobrenome, cpf)values("' . $nome . '","' . $sobrenome . '","' . $cpf. '")';

        $Acesso = new Acesso();

        $Acesso->Conexao();

        $Acesso->Query($insert);
    }
    
   

    public function consultar($sql) {

        $Acesso = new Acesso();

        $Acesso->Conexao();

        $Acesso->Query($sql);

        $this->Linha = @mysqli_affected_rows($Acesso->result);

        $this->Result = $Acesso->result;
    }

    // ----- FUNÇÃO DE EXCLUSÃO DE DADOS ----- //
    
    public function excluir($id) {

        $delete = 'delete from usuario where id="' . $id . '"';

        $Acesso = new Acesso();

        $Acesso->Conexao();

        $Acesso->Query($delete);
    }

    // ----- FUNÇÃO DE EDIÇÃO DE DADOS ----- //
    
    public function alterar($nome, $sobrenome, $cpf, $id) {

        $update = 'update usuario set nome="' . $nome . '", sobrenome="' . $sobrenome . '" , cpf="' . $cpf . '" where id="' . $id . '"';

        $Acesso = new Acesso();

        $Acesso->Conexao();

        $Acesso->Query($update);

        $this->Linha = mysqli_num_rows($Acesso->result);

        $this->Result = $Acesso->result;
    }

}

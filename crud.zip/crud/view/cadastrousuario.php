<?php include('menu.php');  ?> 

<?php include('default.php');   ?>

<?php
require_once('../controller/ControleUsuario.php'); 
Processo('incluir'); 
?>

<script src="js/Validacaoform.js"></script>

<div class="container">

    <form class="form-signin" action="" id="form" name="form" method="post">
        <h2 class="form-signin-heading"></h2>

        <div class="form-group">
            <input type="text" id="nome" name="nome" class="form-control" placeholder="Nome" required autofocus>
            <input type="text" id="sobrenome" name="sobrenome" class="form-control" placeholder="Sobrenome" required>
            
            <input type="text" id="cpf" maxlength="11" name="cpf" class="form-control" placeholder="CPF" required>
        </div>


        <div class="form-group">
            <div>
                <input type="button" name="button" id="button" value="Cadastrar" class="btn btn-primary" onclick="validar(document.form);"/>
                <input type="hidden" name="ok" id="ok"/>
            </div>
        </div>

    </form>

</div> 
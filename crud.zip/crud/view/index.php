
<?php include('menu.php');?>


<h1 align="center"> Bem Vindo<br>
                    Gerencie os cadastros de seus clientes<br>
                     com facilidade e rapidez!            </h1>
<?php include('menu.php');  ?> 

<?php include('default.php');  ?>

<?php
require_once('../controller/ControleUsuario.php'); 
Processo('editar'); 
?>

<script src="js/Validacaoform.js"></script>

<div class="container">

    <form class="form-signin" action="" id="form" name="form" method="post">
        <h2 class="form-signin-heading"></h2>

          <?php while ($row = mysqli_fetch_array($rs)) { ?>
        
        <div class="form-group">
            <input type="text" id="nome" name="nome" class="form-control" value="<?php echo $row['nome']; ?>">
            <input type="text" id="sobrenome" name="sobrenome" class="form-control" value="<?php echo $row['sobrenome']; ?>">
            <input type="text" id="cpf" name="cpf" class="form-control" value="<?php echo $row['cpf']; ?>">
        </div>

   <?php } ?>
        
        <div class="form-group">
            <div>
                <input type="button" name="button" id="button" value="Editar" class="btn btn-primary" onclick="validar(document.form);"/>
                <input type="hidden" name="ok" id="ok" />
            </div>
        </div>

    </form>

</div> 

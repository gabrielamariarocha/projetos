<!DOCTYPE html>
<html lang="en">

    <?php include('default.php'); ?>

    <body>

        <div class="container">

            <div class="masthead">
                <h3>Cadastros</h3><br>
                <nav>
                


                    <ul class="nav nav-justified">
                      <a href="index.php">&nbsp;INICIO&nbsp;</a>
                      <a href="cadastrousuario.php">&nbsp;CADASTRAR&nbsp;</a> 
                    <a href="consultarusuario.php">&nbsp;CONSULTAR&nbsp;</a>

                    </ul>
                </nav>
            </div>
        </div>

    </body>

</html>

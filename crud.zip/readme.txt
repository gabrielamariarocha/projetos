No reposit�rio est� incluso um arquivo .sql com o banco de dados definido.

Para executar o projeto, siga os seguintes passos:

Importe o arquivo sistema.sql para qualquer SGBD dispon�vel.
O banco de dados utiliza as seguintes configura��es: 2.1. Servidor: localhost 2.2. User: root 2.3. Password: (vazio)
Ap�s importar o banco de dados, tente executar a aplica��o.

1. Digite na url localhost/crud/view para iniciar a aplica��o;
2. Na barra superior selecione "cadastrar" para inserir os dados do cliente;
3. No link de consulta � poss�vel observar os dados do cliente cadastrado anteriormente e fazer as altera��es desejadas: editar ou excluir.

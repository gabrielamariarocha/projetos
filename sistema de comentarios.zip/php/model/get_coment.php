<?php

	session_start();
	if(!isset($_SESSION['usuario'])){
		header('Location: ../index.php?erro=1');
	}

	    require_once('db.class.php');
	       $id_usuario = $_SESSION['id_usuario'];

	          $objDb = new db();
	            $link = $objDb->conecta_mysql();
	
	$sql = " SELECT  date_format(c.data_inclusao,'%d %b %Y %T') AS data_inclusao_formatada, c.coment, u.usuario FROM coment AS c JOIN usuarios AS u ON (c.id_usuario = u.id) WHERE id_usuario = $id_usuario OR id_usuario ORDER BY data_inclusao DESC ";
 
	       $resultado_id= mysqli_query($link,$sql);

              if($resultado_id){

    	        while($registo = mysqli_fetch_array($resultado_id, MYSQLI_ASSOC)){
        
           echo '<br><div class="list-group-item">';
             echo '<h4>'.$registo['usuario'].'<small> - '.$registo['data_inclusao_formatada'].' </small>';
               echo '<p class="list-group-item-text">'.$registo['coment'].'</p>';
                 echo '</div>';
      
    }

    } else {
            echo 'Erro';

    }
?>
<?php

      session_start();
      require_once('db.class.php');
        $objDB = new db();
           $link = $objDB->conecta_mysql();

              $id_usuario = $_SESSION['id_usuario'];
                $usuario = $_POST['usuario'];
                  $email = $_POST['email'];
                     $senha = md5($_POST['senha']);


          $sql = "UPDATE usuarios SET usuario = '$usuario', email = '$email', senha = '$senha' WHERE id = '$id_usuario'";

        if (mysqli_query($link,$sql)){
            header('location: ../view/login.php');
        }else{
     
       header("location: ../index.php");

         }
?>

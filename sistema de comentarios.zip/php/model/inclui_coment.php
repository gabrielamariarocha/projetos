<?php

	session_start();

	if(!isset($_SESSION['usuario'])){
		header('Location: ../index.php?erro=1');
	}

	require_once('../model/db.class.php');

	$texto_coment = $_POST['texto_coment'];
	$id_usuario = $_SESSION['id_usuario'];

	if($texto_coment == '' || $id_usuario == ''){
		die();
	}

	$objDb = new db();
	$link = $objDb->conecta_mysql();
	
	$sql = " INSERT INTO coment(id_usuario, coment)values($id_usuario, '$texto_coment') ";

	mysqli_query($link, $sql);

?>
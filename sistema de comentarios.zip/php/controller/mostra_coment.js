
         $(document).ready( function(){
     $('#btn_coment').click( function(){
          
     if($('#texto_coment').val().length > 0){
            
        $.ajax({
        url: '../model/inclui_coment.php',
          method: 'post',
           data: $('#form_coment').serialize(),
             success: function(data) {
                $('#texto_coment').val('');
         atualizaComent();
        }
      });
    }

});

           function atualizaComent(){
    
           $.ajax({
        url: '../model/get_coment.php',
              success: function(data) {
                $('#coment').html(data);
        }
     });
  }

atualizaComent();

});



      $(document).ready(function(){


      function atualizaComent(){
         $.ajax({
           url:"../model/get_coment_geral.php",
           success: function(data) {
             $('#coment').html(data);

           }
         });
       }
       atualizaComent();
       });
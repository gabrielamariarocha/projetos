<!DOCTYPE HTML>
<html lang="pt-br">
<head>
     <title>Bem Vindo</title>
      <meta charset="UTF-8">
      <link rel="stylesheet" href="view/estilo.css">    
</head>    


<body>

             <div id="menu">
                <ul>
                   <li><a href="view/inscrevase.php">CADASTRE-SE</a></li>
                      <li><a href="view/login.php">LOGIN</a></li>
                        <li><a href="view/comentarios.php">VEJA OS COMENTÁRIOS</a></li>
                     </ul>
                </div>



              <p class="texto">B</p>
                     <img src="imagens/ft.png">

            <p class="texto2"> em vindo! Nós da ArrayEnterprises temos<br>
               o prazer de convidar você, nosso cliente, <br>
                a testar nosso novo produto e dizer a sua<br>
                 opinião. Por favor, cadastre-se para deixar<br>
                    seu comentário. Agradeçemos sua visita!</p>


</body>
</html>
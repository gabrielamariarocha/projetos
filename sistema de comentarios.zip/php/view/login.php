<?php

	$erro = isset($_GET['erro']) ? $_GET['erro'] : 0;

?>

<!DOCTYPE HTML>
<html lang="pt-br">
<link rel="stylesheet" href="style.css">
	<head><title>Login</title>
<meta charset="UTF-8">
</head>


  <script>

			
        $(document).ready(function(){
        $('#btn_login').click(function(){
        var campo_vazio = false;
             if($('#campo_usuario').val() == ''){
        
        $('#campo_usuario');
      
        campo_vazio = true;
              }else{
        $('#campo_usuario');
}
            if($('#campo_senha').val() == ''){
        $('#campo_senha');
        campo_vazio = true;
            
             }else{
        $('#campo_senha')
}

            if(campo_vazio) return false;

});

});

     </script>
</head>
     
<body>

	        

<div class="<?= $erro == 1 ? 'open' : '' ?>"></div>

<h1>Olá!</h1>
&nbsp;&nbsp;&nbsp;Insira seus dados para login:
<br><br>
<form method="post" action="../model/validar_acesso.php">

       
    <fieldset>
       <div class="campo">
       <label for="usuario">Usuário:</label>
       <input type="text" class="form-control" id="campo_usuario" name="usuario"/>
       </div>
								
       <br>
       <div class="campo">
       <label for="senha">Senha:</label>
       <input type="password" class="form-control red" id="campo_senha" name="senha"/>
       </div>
    </fieldset>
         
         <br>
         &nbsp;&nbsp;&nbsp;<button type="submit" class="botao" id="btn_login">Entrar</button>
         
<br /><br />
		&nbsp;&nbsp;&nbsp;Ainda não possui uma conta? <a href="inscrevase.php">Cadastrar</a>				
</form>

<?php

if($erro == 1){
echo '<br>&nbsp;&nbsp;&nbsp;Usuário e ou senha inválido(s)';
}
?>
  </body>
</html>







<!DOCTYPE HTML>
<meta charset="UTF-8">
<html lang="pt-br">
<head>
  <link rel="stylesheet" href="../view/style.css">
  <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
  <script type="text/javascript" src="../controller/getdados.js"></script>
  <title>Sistema de Comentário</title>
</head>

<body>
<h1>O que estão dizendo..</h1>

      <div id="coment" class="list-group">
      </div>


</body>
</html>
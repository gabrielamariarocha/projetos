<!DOCTYPE HTML>
<meta charset="UTF-8">
<html lang="pt-br">
<head>
<script type="text/javascript" src="../controler/getdados.js"></script>	
<link rel="stylesheet" href="style.css">


<title>Sistema de Comentário</title>


</head>


  



<body>
	
<h1>Comentários recebidos:</h1>
<div id = 'coment'>
	
</div>
</body>
</html>


<!DOCTYPE HTML>
<html lang="pt-br">
  <head>
        <title>Atualização de Cadastro</title>
           <meta charset="UTF-8">
        <link rel="stylesheet" href="../view/style.css">
</head>

<body>
         <form name="editar" action="../model/editar_cadastro.php" method="post">
             <h1>Preencha os campos para alterar seus dados.</h1>
       
              <fieldset>
                 <div class="campo">
                    <label for="usuario">Usuário:</label>
                        <input type="text" name="usuario" required="required">
                            </div>
                              <br>
                               <div class="campo">
                                   <label for="email">Email:</label>
                                       <input type="text" name="email" required="required">
                                      <br>
                                   <div class="campo">
                                <label for="senha">Senha:</label>
                            <input type="password" name="senha" required="requiored">
                          </div>
                         <br>
                    <button type="submit" class="botao">Atualizar Cadastro</button>
       
</form>
</html>



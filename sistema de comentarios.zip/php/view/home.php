
<?php
	session_start();

	if(!isset($_SESSION['usuario'])){
		header('Location: ../index.php?erro=1');
	}
?>

<!DOCTYPE HTML>
<meta charset="UTF-8">
<html lang="pt-br">
<head>
  <link rel="stylesheet" href="../view/style.css">
  <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
  <script type="text/javascript" src="../controller/mostra_coment.js"></script>
  <title>Sistema de Comentário</title>
</head>

<body>

<br><a href="../index.php" class="linkum">Sair</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="../view/edita.php">Editar Cadastro</a><br>
<h1>Bem Vindo(a)! <?= $_SESSION['usuario'] ?></h1>






       <div class="campo">
           <form id="form_coment" class="input-group">
               &nbsp;Deixe um comentário:<br>
                 <br><textarea id="texto_coment" name="texto_coment" class="form-control"></textarea><br>
             <span class="input-group-btn">
           <br><button class="botao" id="btn_coment" type="submit">Enviar</button>
         </span>
      <div id="coment" class="list-group">
        
      </div>

</form>
</body>
</html>
<?php

	$erro_usuario = isset($_GET['erro_usuario']) ? $_GET['erro_usuario'] : 0;
	$erro_email = isset($_GET['erro_email']) ? $_GET['erro_email'] : 0;

?>

<!DOCTYPE HTML>
<html lang="pt-br">
<link rel="stylesheet" href="style.css">
<head>
         <title>Cadastro</title>
         <meta charset="UTF-8">
</head>

<body>


	        
        <h1>Insira seus dados para realizar o cadastro:</h1>
           <br/>
             <form method="post" action="../model/registra_usuario.php" id="formCadastrarse">


          <fieldset>
           <div class="campo">
             <label for="usuario">Usuário:</label>
               <input type="text" class="form-control" id="usuario" name="usuario" required="required">

 <?php
if($erro_usuario){
echo 'Usuário já existe';
		}
?>
            </div>
                <br>
                  <div class="campo">
                   <label for="email">Email:</label>
                       <input type="email" class="form-control" id="email" name="email" required="required">
<?php
if($erro_email){
echo 'Email já existe';
     }
?>
               </div>
                  <br>			
                     <div class="campo">
                       <label for="senha">Senha:</label>
                         <input type="password" class="form-control" id="senha" name="senha" required="requiored">
                         </div>

              <br>					
                  <button type="submit" class="botao">Cadastrar</button>
              <br>
                   <a href="../index.php">Voltar</a>
</form>
</body>
</html>
No reposit�rio est� incluso um arquivo .sql com o banco de dados definido.

Para executar o projeto, siga os seguintes passos:

Importe o arquivo sistema.sql para qualquer SGBD dispon�vel.
O banco de dados utiliza as seguintes configura��es: 2.1. Servidor: localhost 2.2. User: root 2.3. Password: (vazio)
Ap�s importar o banco de dados, tente executar a aplica��o.

1. Ap�s abrir o index.php, ser� necessario primeiramente realizar o cadastro, que se localiza na parte superior
da tela. 

2.Ap�s os campos do cadastro terem sido preenchidos, deve-se entrar no link 'logar' e preencher os campos do login com as mesmas informa��es fornecidas para o cadastro.

3.Home, nessa se��o � permitido realizar coment�rios, e visualizar o coment�rio de outros usu�rios.

4.Na parte superior na p�gina � possivel sair, ou fazer altera��o de dados cadastrais.

5.Ap�s a mudan�a dos dados cadastrais, efetue o login com as novas informa��es.
